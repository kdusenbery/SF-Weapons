function newPicture() {
	
	document.getElementById("image").src="soldierM4.jpg";
	
}

function oldPicture() {
	
	document.getElementById("image").src="M4.jpg";
	
}